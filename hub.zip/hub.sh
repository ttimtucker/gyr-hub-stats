#!/bin/bash
IFS=","
generateHeader() {
#set -x
	echo -n "Site"
	while read clientStatus 
	do
		if [[ ${clientStatus:0:1} == '#' ]]
		then
			continue
		else
			echo -n ";$clientStatus"
		fi
	done < status.txt
	echo
}

./login.curl 
./assigned-clients.curl > /dev/null 2>&1
./all-clients.curl > /dev/null 2>&1
./all-clients-clear.curl > /dev/null 2>&1
generateHeader
while read siteNum siteName
do
	#echo "Using site number $siteNum"

	echo -n "$siteName"
	while read clientStatus 
	do
		#echo "clientStatus=$clientStatus"
		#echo "firstchar=${clientStatus:0:1}"
		if [[ ${clientStatus:0:1} == '#' ]]
		then
			#echo "hash found"
			continue
		else

			#echo "hash not found"
			#echo "Using status: $clientStatus"
			./all-clients-impact-readyForPrep.curl $siteNum $clientStatus> results.txt  2>&1
        		grep "No clients found" results.txt > /dev/null 2>&1
			if [ $? -eq 0 ]
			then
				total=0
			else
				display=$(grep "Displaying" results.txt)
				total=$(echo $display|sed -e 's/^.*of//g'|sed -e 's/[^0-9]//g')
			fi
			echo -n ";$total"

		fi
	done < status.txt
done < sites.txt

